package banco;

import model.GuiaEstudos;

public class GuiaEstudosBanco {
    public void inserirGuiaEstudos(GuiaEstudos guiaEstudos){
    }
}
