package model;

import javax.xml.crypto.Data;

public abstract class ArtefatoInteratividade {
    private String tipo;
    private String titulo;
    private String descricao;
    private Data dataPostagem;
	private Materia materia;
    
    public ArtefatoInteratividade(String tipo, String titulo, String descricao, Materia materia) {
		this.tipo = tipo;
		this.titulo = titulo;
		this.descricao = descricao;
		this.materia = materia;
	}
    
    public ArtefatoInteratividade(String tipo, String titulo, String descricao, Materia materia, Data dataPostagem) {
		this.tipo = tipo;
		this.titulo = titulo;
		this.descricao = descricao;
		this.materia = materia;
		this.dataPostagem = dataPostagem;
	}

	public abstract void agendarDataPostagem();
    public abstract void deletarArtefato();
    public abstract void editarArtefato();
    public abstract void criarArtefato();
    
}
