package model;

import javax.xml.crypto.Data;

public class Mensagem {
    private String texto;
    private String arquivo;
    private Data dataHora;
    private String remetente;
}
