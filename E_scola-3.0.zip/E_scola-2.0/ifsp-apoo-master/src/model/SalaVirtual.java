package model;

import java.util.List;

public class SalaVirtual {
    private static int proximoCodigoSala = 0001;

    private String nome;
    private String descricao;
    private String miniatura;
    private Integer volumetria;
    private Integer codigoSala;
    private Materia materia;
    private boolean isAtivo;
    private List<Estudante> estudantes;

    public SalaVirtual(String nome, String descricao, String miniatura, Materia materia) {
        this.nome = nome;
        this.descricao = descricao;
        this.miniatura = miniatura;
        this.materia = materia;
        this.codigoSala = proximoCodigoSala++;
        this.volumetria = 0;
    }

    public void alterarIsAtivo(){
        this.isAtivo = !this.isAtivo;
    }

    public void atualizarSalaVirtual(String nome, String descricao, String miniatura) {
        this.nome = nome;
        this.descricao = descricao;
        this.miniatura = miniatura;
    }

    public void incluirEstudante(Estudante estudante){
        this.estudantes.add(estudante);
        this.atualizarVolumetriaEstudantes();
    }

    public void excluirEstudante(Estudante estudante){
        this.estudantes.remove(estudante);
        this.atualizarVolumetriaEstudantes();
    }

    private void atualizarVolumetriaEstudantes(){
        this.volumetria = this.estudantes.size();
    }
}
