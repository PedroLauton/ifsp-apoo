package model;

public class Notificacao {
    private String titulo;
    private String descricao;
    private boolean visualizado;
    private Atividade atividade;

    public Notificacao(String titulo, String descricao) {
        this.titulo = titulo;
        this.descricao = descricao;
        this.visualizado = false;
    }

    public void visualizarNotificacao(){
        this.visualizado = true;
    }

    public void deletarNotificacao(){
        //
    }


}
