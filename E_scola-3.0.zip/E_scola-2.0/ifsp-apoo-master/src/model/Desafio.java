package model;

import java.util.List;
import javax.xml.crypto.Data;

public class Desafio extends ArtefatoInteratividade{
	private List<String> requisitos;

    public Desafio(String tipo, String titulo, String descricao, List<String> requisitos, Materia materia) {
        super(tipo, titulo, descricao, materia);
        this.requisitos.addAll(requisitos);
    }

    public Desafio(String tipo, String titulo, String descricao, List<String> requisitos, Materia materia, Data dataPostagem) {
        super(tipo, titulo, descricao, materia, dataPostagem);
        this.requisitos.addAll(requisitos);
    }


	@Override
	protected void agendarDataPostagem() {

	}

	@Override
	public void deletarArtefato() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void editarArtefato() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void criarArtefato() {
		// TODO Auto-generated method stub
		
	}
}
