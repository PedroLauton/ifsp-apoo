package model;

import java.util.List;
import javax.xml.crypto.Data;

public class AtividadeColaborativa extends ArtefatoInteratividade {
    private List<String> requisitos;
    private List<String> entregaveis;

    public AtividadeColaborativa(String tipo, String titulo, String descricao, List<String> requisitos, List<String> entregaveis, Materia materia) {
        super(tipo, titulo, descricao, materia);
        this.requisitos.addAll(requisitos);
        this.entregaveis.addAll(entregaveis);
    }

    public AtividadeColaborativa(String tipo, String titulo, String descricao, List<String> requisitos, List<String> entregaveis, Materia materia, Data dataPostagem) {
        super(tipo, titulo, descricao, materia, dataPostagem);
        this.requisitos.addAll(requisitos);
        this.entregaveis.addAll(entregaveis);
    }


    @Override
    public void agendarDataPostagem() {

    }

    @Override
    public void deletarArtefato() {

    }

    @Override
    public void editarArtefato() {

    }

    @Override
    public void criarArtefato() {

    }
}
