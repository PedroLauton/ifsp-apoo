package model;

import javax.xml.crypto.Data;
import java.util.List;

public class Atividade {
    private String nome;
    private Data dataInicio;
    private Data dataTermino;
    private SalaVirtual salaVirtual;
    private Notificacao notificacao;
    private List<EncontroSincrono> encontroSincrono;

    public void consultarAtividade(){
        //
    }

    public void adicionarAtiviade(){
        //
    }

    public void deletarCronograma(){
        //
    }



}
