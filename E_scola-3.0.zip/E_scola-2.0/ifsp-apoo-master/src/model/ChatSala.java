package model;

import java.util.List;

public class ChatSala {
    private String titulo;
    private SalaVirtual salaVirtual;
    private List<Mensagem> mensagens;

    public ChatSala(String titulo, SalaVirtual salaVirtual) {
        this.titulo = titulo;
        this.salaVirtual = salaVirtual;
    }

    public void atualizarChat(){
        //
    }

    public void carregarChat(){
        //
    }

    public void arquivarChat(){
        //
    }

    public void consultarHistoricoChat(){
        //
    }


}
