package model;

public class MaterialComplementar {
    private String arquivo;
    private String titulo;
    private String miniatura;
    private String descricao;

    public MaterialComplementar(String materia, String arquivo, String titulo, String miniatura, String descricao) {
        this.arquivo = arquivo;
        this.titulo = titulo;
        this.miniatura = miniatura;
        this.descricao = descricao;
    }

    public void editarMaterial(String materia, String arquivo, String titulo, String miniatura, String descricao){
        this.arquivo = arquivo;
        this.titulo = titulo;
        this.miniatura = miniatura;
        this.descricao = descricao;
    }

    public String getTitulo() {
        return titulo;
    }
}
