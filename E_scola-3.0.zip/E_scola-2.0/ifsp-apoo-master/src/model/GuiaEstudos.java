package model;

import javax.xml.crypto.Data;
import java.util.List;

public class GuiaEstudos {
    private String titulo;
    private Data dataInicio;
    private Data dataFim;
    private String ramo;
    private Materia materia;
    private String resumo;
    private String link;
    private List<MaterialComplementar> materialComplementar;

    public GuiaEstudos(String titulo, Data dataInicio, Data dataFim, String ramo, Materia materia, String resumos, String links) {
        this.titulo = titulo;
        this.dataInicio = dataInicio;
        this.dataFim = dataFim;
        this.ramo = ramo;
        this.materia = materia;
        this.resumo = resumos;
        this.link = links;
    }

    public String getTituloGuia() {
        return titulo;
    }

    public void atualizarGuia(String titulo, Data dataInicio, Data dataFim, String ramo){
        this.titulo = titulo;
        this.dataInicio = dataInicio;
        this.dataFim = dataFim;
        this.ramo = ramo;
    }

    public void adicionarMaterialComplementar(MaterialComplementar material){
        if (material == null) {
            throw new IllegalArgumentException("Material complementar está vazio.");
        }
        this.materialComplementar.add(material);
    }

    public boolean removerMaterialComplementar(String tituloMaterial) {
        if (tituloMaterial == null || tituloMaterial.isEmpty()) {
            throw new IllegalArgumentException("O nome do Material Complementar não pode ser nulo ou vazio.");
        }

        for (int i = 0; i < this.materialComplementar.size(); i++) {
            MaterialComplementar dadosMaterial = this.materialComplementar.get(i);
            if (dadosMaterial.getTitulo().equals(tituloMaterial)) {
                this.materialComplementar.remove(i);
                return true;
            }
        }
        return false;
    }

    public void deletarGuia(){
        //Não entendi como fazer;
    }

}
