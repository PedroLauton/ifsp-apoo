package model;

import javax.xml.crypto.Data;

public class Cronograma {
    private String nome;
    private Data dataInicio;
    private Data dataTermino;
}
