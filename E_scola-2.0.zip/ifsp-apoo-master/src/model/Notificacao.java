package model;

public class Notificacao {
    private String titulo;
    private String descricao;
    private boolean visualizado;
}
