package model;

public class Estudante {
    private Integer matricula;
    private String nome;
    private String cpf;
    private String rg;
    private String email;
    private String telefone;
    private String endereco;
    private String escola;
}
