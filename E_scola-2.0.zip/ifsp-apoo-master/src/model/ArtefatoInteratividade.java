package model;

import javax.xml.crypto.Data;

public abstract class ArtefatoInteratividade {
    private String tipo;
    private String titulo;
    private String descricao;
    private Data dataPostagem;
    
    public ArtefatoInteratividade(String tipo, String titulo, String descricao) {
		this.tipo = tipo;
		this.titulo = titulo;
		this.descricao = descricao;
	}
    
    public ArtefatoInteratividade(String tipo, String titulo, String descricao, Data dataPostagem) {
		this.tipo = tipo;
		this.titulo = titulo;
		this.descricao = descricao;
		this.dataPostagem = dataPostagem;
	}

	public abstract void agendarDataPostagem();
    public abstract void deletarArtefato();
    public abstract void editarArtefato();
    public abstract void criarArtefato();
    
}
