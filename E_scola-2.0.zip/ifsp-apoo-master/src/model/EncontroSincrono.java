package model;

public class EncontroSincrono {
    private String assunto;
    private String descricao;
    private String dataHorario;
    private String tags;
    private String linkConteudo;
    private String ramo;
    private String recompensa;
}
