package model;

import java.util.List;
import javax.xml.crypto.Data;

public class Pergunta extends ArtefatoInteratividade{
    private List<String> opcoes;
    private String resposta;

    public Pergunta(String tipo, String titulo, String descricao, String opcoes, String resposta) {
        super(tipo, titulo, descricao);
        this.opcoes.add(opcoes);
        this.resposta = resposta;
    }

    public Pergunta(String tipo, String titulo, String descricao, String opcoes, String resposta, Data dataPostagem) {
        super(tipo, titulo, descricao, dataPostagem);
        this.opcoes.add(opcoes);
        this.resposta = resposta;
    }

	@Override
	public void agendarDataPostagem() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deletarArtefato() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void editarArtefato() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void criarArtefato() {
		// TODO Auto-generated method stub
		
	}
}
