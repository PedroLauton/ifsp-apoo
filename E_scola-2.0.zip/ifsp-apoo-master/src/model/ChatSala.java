package model;

public class ChatSala {
    private String titulo;
    private Integer participantes;
}
