package model;

import java.util.List;
import javax.xml.crypto.Data;

public class Enquete extends ArtefatoInteratividade{
    private List<String> opcoes;
    private String resposta;

    public Enquete(String tipo, String titulo, String descricao, List<String> opcoes, String resposta) {
        super(tipo, titulo, descricao);
        this.opcoes.addAll(opcoes);
        this.resposta = resposta;
    }

    public Enquete(String tipo, String titulo, String descricao, List<String> opcoes, String resposta, Data dataPostagem) {
        super(tipo, titulo, descricao, dataPostagem);
        this.opcoes.addAll(opcoes);
        this.resposta = resposta;
    }

	@Override
	public void agendarDataPostagem() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deletarArtefato() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void editarArtefato() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void criarArtefato() {
		// TODO Auto-generated method stub
		
	}
    
    
}
