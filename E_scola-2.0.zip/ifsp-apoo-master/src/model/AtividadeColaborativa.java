package model;

import java.util.List;
import javax.xml.crypto.Data;

public class AtividadeColaborativa extends ArtefatoInteratividade {
    private List<String> requisitos;
    private List<String> entregaveis;

    public AtividadeColaborativa(String tipo, String titulo, String descricao, List<String> requisitos, List<String> entregaveis) {
        super(tipo, titulo, descricao);
        this.requisitos.addAll(requisitos);
        this.entregaveis.addAll(entregaveis);
    }

    public AtividadeColaborativa(String tipo, String titulo, String descricao, List<String> requisitos, List<String> entregaveis, Data dataPostagem) {
        super(tipo, titulo, descricao, dataPostagem);
        this.requisitos.addAll(requisitos);
        this.entregaveis.addAll(entregaveis);
    }

	@Override
	public void agendarDataPostagem() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deletarArtefato() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void editarArtefato() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void criarArtefato() {
		// TODO Auto-generated method stub
		
	}
    
    
}
