package model;

public class SalaVirtual {
    private String nome;
    private String descricao;
    private String miniatura;
    private Integer volumetria;
    private Integer codigoSala;
}
