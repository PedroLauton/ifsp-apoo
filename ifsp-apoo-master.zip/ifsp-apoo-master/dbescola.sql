-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 08/08/2024 às 20:38
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `dbescola`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `tbartefatointeratividade`
--

CREATE TABLE `tbartefatointeratividade` (
  `cod` int(11) NOT NULL,
  `tipo` varchar(150) DEFAULT NULL,
  `titulo` varchar(150) DEFAULT NULL,
  `descricao` varchar(300) DEFAULT NULL,
  `dataPostagem` date NOT NULL,
  `opcoes` text DEFAULT NULL,
  `resposta` int(11) DEFAULT NULL,
  `requisitos` text DEFAULT NULL,
  `entregaveis` text DEFAULT NULL,
  `materia` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tbatividade`
--

CREATE TABLE `tbatividade` (
  `cod` int(11) NOT NULL,
  `nome` varchar(150) DEFAULT NULL,
  `dataInicio` datetime DEFAULT NULL,
  `dataTermino` datetime DEFAULT NULL,
  `salavirtual` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tbchatsala`
--

CREATE TABLE `tbchatsala` (
  `cod` int(11) NOT NULL,
  `titulo` varchar(150) DEFAULT NULL,
  `salaVirtual` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tbencontrosincrono`
--

CREATE TABLE `tbencontrosincrono` (
  `cod` int(11) NOT NULL,
  `assunto` varchar(150) DEFAULT NULL,
  `descricao` varchar(300) DEFAULT NULL,
  `dataHorario` datetime DEFAULT NULL,
  `tags` varchar(100) DEFAULT NULL,
  `linkConteudo` varchar(300) DEFAULT NULL,
  `ramo` varchar(150) DEFAULT NULL,
  `recompensa` varchar(150) DEFAULT NULL,
  `atividade` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tbestudante`
--

CREATE TABLE `tbestudante` (
  `matricula` int(11) NOT NULL,
  `nome` varchar(150) DEFAULT NULL,
  `cpf` char(14) DEFAULT NULL,
  `rg` varchar(20) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `endereco` varchar(200) DEFAULT NULL,
  `escola` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tbestudantes_salavirtual`
--

CREATE TABLE `tbestudantes_salavirtual` (
  `cod` int(11) NOT NULL,
  `estudante` int(11) DEFAULT NULL,
  `salavirtual` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tbguiaestudos`
--

CREATE TABLE `tbguiaestudos` (
  `cod` int(11) NOT NULL,
  `titulo` varchar(150) DEFAULT NULL,
  `dataInicio` date DEFAULT NULL,
  `dataFim` date DEFAULT NULL,
  `ramo` varchar(150) DEFAULT NULL,
  `materia` int(11) DEFAULT NULL,
  `resumo` varchar(1000) DEFAULT NULL,
  `link` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tbguiaestudos_materialcomplementar`
--

CREATE TABLE `tbguiaestudos_materialcomplementar` (
  `cod` int(11) NOT NULL,
  `guiaestudos` int(11) DEFAULT NULL,
  `materialcomplementar` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tbmateria`
--

CREATE TABLE `tbmateria` (
  `cod` int(11) NOT NULL,
  `nome` varchar(150) DEFAULT NULL,
  `sigla` char(4) DEFAULT NULL,
  `desativado` tinyint(1) DEFAULT NULL,
  `professor` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tbmaterialcomplementar`
--

CREATE TABLE `tbmaterialcomplementar` (
  `cod` int(11) NOT NULL,
  `arquivo` varchar(500) DEFAULT NULL,
  `titulo` varchar(150) DEFAULT NULL,
  `miniatura` varchar(500) DEFAULT NULL,
  `descricao` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tbmensagem`
--

CREATE TABLE `tbmensagem` (
  `cod` int(11) NOT NULL,
  `texto` text DEFAULT NULL,
  `arquivo` varchar(500) DEFAULT NULL,
  `dataHora` datetime DEFAULT NULL,
  `chat` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tbnotificacao`
--

CREATE TABLE `tbnotificacao` (
  `cod` int(11) NOT NULL,
  `titulo` varchar(150) DEFAULT NULL,
  `descricao` varchar(300) DEFAULT NULL,
  `visualizado` tinyint(1) DEFAULT NULL,
  `atividade` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tbprofessor`
--

CREATE TABLE `tbprofessor` (
  `matricula` int(11) NOT NULL,
  `especialidade` varchar(100) DEFAULT NULL,
  `nome` varchar(150) DEFAULT NULL,
  `cpf` char(14) DEFAULT NULL,
  `rg` varchar(20) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `endereco` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tbprofessor`
--

INSERT INTO `tbprofessor` (`matricula`, `especialidade`, `nome`, `cpf`, `rg`, `email`, `telefone`, `endereco`) VALUES
(1, 'Química', 'Pedro', '40028922029', '50395859391', 'pedro@gmail.com', '34338945', 'Divisa do nada com o vazio');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tbsalavirtual`
--

CREATE TABLE `tbsalavirtual` (
  `cod` int(11) NOT NULL,
  `nome` varchar(150) DEFAULT NULL,
  `descricao` varchar(300) DEFAULT NULL,
  `miniatura` varchar(500) DEFAULT NULL,
  `volumetriaEstudantes` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `tbartefatointeratividade`
--
ALTER TABLE `tbartefatointeratividade`
  ADD PRIMARY KEY (`cod`),
  ADD KEY `materia` (`materia`);

--
-- Índices de tabela `tbatividade`
--
ALTER TABLE `tbatividade`
  ADD PRIMARY KEY (`cod`),
  ADD KEY `salavirtual` (`salavirtual`);

--
-- Índices de tabela `tbchatsala`
--
ALTER TABLE `tbchatsala`
  ADD PRIMARY KEY (`cod`),
  ADD UNIQUE KEY `salaVirtual` (`salaVirtual`);

--
-- Índices de tabela `tbencontrosincrono`
--
ALTER TABLE `tbencontrosincrono`
  ADD PRIMARY KEY (`cod`),
  ADD KEY `atividade` (`atividade`);

--
-- Índices de tabela `tbestudante`
--
ALTER TABLE `tbestudante`
  ADD PRIMARY KEY (`matricula`);

--
-- Índices de tabela `tbestudantes_salavirtual`
--
ALTER TABLE `tbestudantes_salavirtual`
  ADD PRIMARY KEY (`cod`),
  ADD KEY `estudante` (`estudante`),
  ADD KEY `salavirtual` (`salavirtual`);

--
-- Índices de tabela `tbguiaestudos`
--
ALTER TABLE `tbguiaestudos`
  ADD PRIMARY KEY (`cod`),
  ADD KEY `materia` (`materia`);

--
-- Índices de tabela `tbguiaestudos_materialcomplementar`
--
ALTER TABLE `tbguiaestudos_materialcomplementar`
  ADD PRIMARY KEY (`cod`),
  ADD KEY `guiaestudos` (`guiaestudos`),
  ADD KEY `materialcomplementar` (`materialcomplementar`);

--
-- Índices de tabela `tbmateria`
--
ALTER TABLE `tbmateria`
  ADD PRIMARY KEY (`cod`),
  ADD KEY `professor` (`professor`);

--
-- Índices de tabela `tbmaterialcomplementar`
--
ALTER TABLE `tbmaterialcomplementar`
  ADD PRIMARY KEY (`cod`);

--
-- Índices de tabela `tbmensagem`
--
ALTER TABLE `tbmensagem`
  ADD PRIMARY KEY (`cod`),
  ADD KEY `chat` (`chat`);

--
-- Índices de tabela `tbnotificacao`
--
ALTER TABLE `tbnotificacao`
  ADD PRIMARY KEY (`cod`),
  ADD KEY `atividade` (`atividade`);

--
-- Índices de tabela `tbprofessor`
--
ALTER TABLE `tbprofessor`
  ADD PRIMARY KEY (`matricula`);

--
-- Índices de tabela `tbsalavirtual`
--
ALTER TABLE `tbsalavirtual`
  ADD PRIMARY KEY (`cod`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `tbestudantes_salavirtual`
--
ALTER TABLE `tbestudantes_salavirtual`
  MODIFY `cod` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `tbguiaestudos`
--
ALTER TABLE `tbguiaestudos`
  MODIFY `cod` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `tbmateria`
--
ALTER TABLE `tbmateria`
  MODIFY `cod` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `tbmaterialcomplementar`
--
ALTER TABLE `tbmaterialcomplementar`
  MODIFY `cod` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `tbartefatointeratividade`
--
ALTER TABLE `tbartefatointeratividade`
  ADD CONSTRAINT `tbartefatointeratividade_ibfk_1` FOREIGN KEY (`materia`) REFERENCES `tbmateria` (`cod`);

--
-- Restrições para tabelas `tbatividade`
--
ALTER TABLE `tbatividade`
  ADD CONSTRAINT `tbatividade_ibfk_1` FOREIGN KEY (`salavirtual`) REFERENCES `tbsalavirtual` (`cod`);

--
-- Restrições para tabelas `tbencontrosincrono`
--
ALTER TABLE `tbencontrosincrono`
  ADD CONSTRAINT `tbencontrosincrono_ibfk_1` FOREIGN KEY (`atividade`) REFERENCES `tbatividade` (`cod`);

--
-- Restrições para tabelas `tbestudantes_salavirtual`
--
ALTER TABLE `tbestudantes_salavirtual`
  ADD CONSTRAINT `tbestudantes_salavirtual_ibfk_1` FOREIGN KEY (`estudante`) REFERENCES `tbestudante` (`matricula`),
  ADD CONSTRAINT `tbestudantes_salavirtual_ibfk_2` FOREIGN KEY (`salavirtual`) REFERENCES `tbsalavirtual` (`cod`);

--
-- Restrições para tabelas `tbguiaestudos`
--
ALTER TABLE `tbguiaestudos`
  ADD CONSTRAINT `tbguiaestudos_ibfk_1` FOREIGN KEY (`materia`) REFERENCES `tbmateria` (`cod`);

--
-- Restrições para tabelas `tbguiaestudos_materialcomplementar`
--
ALTER TABLE `tbguiaestudos_materialcomplementar`
  ADD CONSTRAINT `tbguiaestudos_materialcomplementar_ibfk_1` FOREIGN KEY (`guiaestudos`) REFERENCES `tbguiaestudos` (`cod`),
  ADD CONSTRAINT `tbguiaestudos_materialcomplementar_ibfk_2` FOREIGN KEY (`materialcomplementar`) REFERENCES `tbmaterialcomplementar` (`cod`);

--
-- Restrições para tabelas `tbmateria`
--
ALTER TABLE `tbmateria`
  ADD CONSTRAINT `tbmateria_ibfk_1` FOREIGN KEY (`professor`) REFERENCES `tbprofessor` (`matricula`);

--
-- Restrições para tabelas `tbmensagem`
--
ALTER TABLE `tbmensagem`
  ADD CONSTRAINT `tbmensagem_ibfk_1` FOREIGN KEY (`chat`) REFERENCES `tbchatsala` (`cod`);

--
-- Restrições para tabelas `tbnotificacao`
--
ALTER TABLE `tbnotificacao`
  ADD CONSTRAINT `tbnotificacao_ibfk_1` FOREIGN KEY (`atividade`) REFERENCES `tbatividade` (`cod`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
