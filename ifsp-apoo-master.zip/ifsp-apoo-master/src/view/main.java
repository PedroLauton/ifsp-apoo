package view;

import banco.*;
import model.*;

import java.sql.Date;


public class main {
    public static void main(String[] args) {
        Professor professor = new Professor("Química",0001, "Pedro", "40028922029", "50395859391", "pedro@gmail.com", "34338945", "Divisa do nada com o vazio");
        //ProfessorBanco professorBanco = new ProfessorBanco();
        //professorBanco.inserirProfessor(professor);
        //long millis = System.currentTimeMillis();

        Materia materia = new Materia("Química", "QUI", professor);
        //GuiaEstudos guiaEstudos = new GuiaEstudos("Tabela Periódica", new Date(millis), new Date(millis), "Química", "Tabela periódica contém os elementos que regem o mundo", "https://www.youtube.com/watch?v=dQw4w9WgXcQ&ab_channel=RickAstley");
        //GuiaEstudosBanco guiaEstudosBanco = new GuiaEstudosBanco();
        //guiaEstudosBanco.inserirGuiaEstudos(guiaEstudos);
        //MateriaBanco materiaBanco = new MateriaBanco();
        //materiaBanco.inserirMateria(materia);

        SalaVirtual salaVirtual1 = new SalaVirtual(234,"Sala 1", "Teste 1", "Jorge", materia);
        SalaVirtual salaVirtual2 = new SalaVirtual(122,"Sala 1", "Teste 1", "Jorge", materia);
        SalaVirtual salaVirtual3 = new SalaVirtual(433,"Sala 1", "Teste 1", "Jorge", materia);


        SalaVirtualBanco salaVirtualBanco = new SalaVirtualBanco();
        salaVirtualBanco.inserirSalaVirtual(salaVirtual1);
        salaVirtualBanco.inserirSalaVirtual(salaVirtual2);
        salaVirtualBanco.inserirSalaVirtual(salaVirtual3);

        Estudante estudante = new Estudante(001, "jorge", "jorge", "jorge", "jorge", "jorge", "jorge", "jorge", salaVirtual1);
        estudante.inserirSalaVirtual(salaVirtual2);
        estudante.inserirSalaVirtual(salaVirtual3);

        EstudanteBanco estudanteBanco = new EstudanteBanco();
        estudanteBanco.inserirEstudante(estudante);
    }
}
