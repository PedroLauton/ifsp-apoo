package model;

import javax.xml.crypto.Data;
import java.sql.Date;
import java.util.List;

public class GuiaEstudos {
    private static Integer codDiferenciador = 100;
    private Integer codGuiaEstudos;
    private String titulo;
    private Date dataInicio;
    private Date dataFim;
    private String ramo;
    private Materia materia;
    private String resumo;
    private String link;
    private List<MaterialComplementar> materialComplementar;

    public GuiaEstudos(String titulo, Date dataInicio, Date dataFim, String ramo, Materia materia, String resumos, String links) {
        this.codGuiaEstudos = codDiferenciador++;
        this.titulo = titulo;
        this.dataInicio = dataInicio;
        this.dataFim = dataFim;
        this.ramo = ramo;
        this.materia = materia;
        this.resumo = resumos;
        this.link = links;
    }

    public List<MaterialComplementar> getMaterialComplementar() {
        return materialComplementar;
    }

    public String getLink() {
        return link;
    }

    public String getResumo() {
        return resumo;
    }

    public Materia getMateria() {
        return materia;
    }

    public String getRamo() {
        return ramo;
    }

    public Date getDataFim() {
        return dataFim;
    }

    public Date getDataInicio() {
        return dataInicio;
    }

    public String getTitulo() {
        return titulo;
    }

    public void atualizarGuia(String titulo, Date dataInicio, Date dataFim, String ramo){
        this.titulo = titulo;
        this.dataInicio = dataInicio;
        this.dataFim = dataFim;
        this.ramo = ramo;
    }

    public void adicionarMaterialComplementar(MaterialComplementar material){
        if (material == null) {
            throw new IllegalArgumentException("Material complementar está vazio.");
        }
        this.materialComplementar.add(material);
    }

    public boolean removerMaterialComplementar(String tituloMaterial) {
        if (tituloMaterial == null || tituloMaterial.isEmpty()) {
            throw new IllegalArgumentException("O nome do Material Complementar não pode ser nulo ou vazio.");
        }

        for (int i = 0; i < this.materialComplementar.size(); i++) {
            MaterialComplementar dadosMaterial = this.materialComplementar.get(i);
            if (dadosMaterial.getTitulo().equals(tituloMaterial)) {
                this.materialComplementar.remove(i);
                return true;
            }
        }
        return false;
    }

    public void deletarGuia(){
        //Não entendi como fazer;
    }

}
