package model;

import java.util.Date;
import java.util.List;

public class AtividadeColaborativa extends ArtefatoInteratividade {
    private String requisitos;
    private String entregaveis;

    public AtividadeColaborativa(String tipo, String titulo, String descricao, String requisitos, String entregaveis, Materia materia) {
        super(tipo, titulo, descricao, materia);
        this.requisitos = requisitos;
        this.entregaveis = entregaveis;
    }

    public AtividadeColaborativa(String tipo, String titulo, String descricao, String requisitos, String entregaveis, Materia materia, Date dataPostagem) {
        super(tipo, titulo, descricao, materia, dataPostagem);
        this.requisitos = requisitos;
        this.entregaveis = entregaveis;
    }

    public String getRequisitos() {
        return requisitos;
    }

    public String getEntregaveis() {
        return entregaveis;
    }

    @Override
    public void agendarDataPostagem() {

    }

    @Override
    public void deletarArtefato() {

    }

    @Override
    public void editarArtefato() {

    }

    @Override
    public void criarArtefato() {

    }
}
