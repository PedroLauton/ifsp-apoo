package model;

import java.util.ArrayList;
import java.util.List;

public class Estudante {
    private Integer matricula;
    private String nome;
    private String cpf;
    private String rg;
    private String email;
    private String telefone;
    private String endereco;
    private String escola;
    private List<SalaVirtual> salaVirtual = new ArrayList<SalaVirtual>();

    public Estudante(Integer matricula, String nome, String cpf, String rg, String email, String telefone, String endereco, String escola, SalaVirtual salaVirtual) {
        this.matricula = matricula;
        this.nome = nome;
        this.cpf = cpf;
        this.rg = rg;
        this.email = email;
        this.telefone = telefone;
        this.endereco = endereco;
        this.escola = escola;
        this.salaVirtual.add(salaVirtual);
    }

    public Estudante(Integer matricula, String nome, String cpf, String rg, String email, String telefone, String endereco, String escola) {
        this.matricula = matricula;
        this.nome = nome;
        this.cpf = cpf;
        this.rg = rg;
        this.email = email;
        this.telefone = telefone;
        this.endereco = endereco;
        this.escola = escola;
        this.salaVirtual = null;
    }

    public void inserirSalaVirtual(SalaVirtual salaVirtual){
        this.salaVirtual.add(salaVirtual);
    }

    public Integer getMatricula() {
        return matricula;
    }

    public String getNome() {
        return nome;
    }

    public String getCpf() {
        return cpf;
    }

    public String getRg() {
        return rg;
    }

    public String getEmail() {
        return email;
    }

    public String getTelefone() {
        return telefone;
    }

    public String getEndereco() {
        return endereco;
    }

    public String getEscola() {
        return escola;
    }

    public List<SalaVirtual> getSalaVirtual() {
        return salaVirtual;
    }

    public Estudante(String email, String telefone, String endereco) {
        this.email = email;
        this.telefone = telefone;
        this.endereco = endereco;
    }
}
