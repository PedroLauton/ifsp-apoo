package model;

public class MaterialComplementar {
    private String arquivo;
    private String titulo;
    private String miniatura;
    private String descricao;

    public MaterialComplementar(String arquivo, String titulo, String miniatura, String descricao) {
        this.arquivo = arquivo;
        this.titulo = titulo;
        this.miniatura = miniatura;
        this.descricao = descricao;
    }

    public void editarMaterial(String arquivo, String titulo, String miniatura, String descricao){
        this.arquivo = arquivo;
        this.titulo = titulo;
        this.miniatura = miniatura;
        this.descricao = descricao;
    }

    public String getArquivo() {
        return arquivo;
    }

    public String getMiniatura() {
        return miniatura;
    }

    public String getDescricao() {
        return descricao;
    }

    public String getTitulo() {
        return titulo;
    }
}
