package model;

import java.util.Date;


public abstract class ArtefatoInteratividade {
    private String tipo;
    private String titulo;
    private String descricao;
    private Date dataPostagem;
	private Materia materia;
	private Integer codArtefato;
    
    public ArtefatoInteratividade(String tipo, String titulo, String descricao, Materia materia) {
		this.tipo = tipo;
		this.titulo = titulo;
		this.descricao = descricao;
		this.materia = materia;
	}
    
    public ArtefatoInteratividade(String tipo, String titulo, String descricao, Materia materia, Date dataPostagem) {
		this.tipo = tipo;
		this.titulo = titulo;
		this.descricao = descricao;
		this.materia = materia;
		this.dataPostagem = dataPostagem;
	}

	public String getTipo() {
		return tipo;
	}

	public Integer getCodArtefato() {
		return codArtefato;
	}

	public Materia getMateria() {
		return materia;
	}

	public java.sql.Date getDataPostagem() {
		return (java.sql.Date) dataPostagem;
	}

	public String getDescricao() {
		return descricao;
	}

	public String getTitulo() {
		return titulo;
	}

	public abstract void agendarDataPostagem();
    public abstract void deletarArtefato();
    public abstract void editarArtefato();
    public abstract void criarArtefato();
    
}
