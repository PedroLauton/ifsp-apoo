package model;

import java.util.Date;
import java.util.List;
import javax.xml.crypto.Data;

public class Desafio extends ArtefatoInteratividade{
	private String requisitos;

    public Desafio(String tipo, String titulo, String descricao, String requisitos, Materia materia, Date dataPostagem) {
        super(tipo, titulo, descricao, materia, dataPostagem);
        this.requisitos = requisitos;
    }

	public String getRequisitos() {
		return requisitos;
	}

	@Override
	public void agendarDataPostagem() {

	}

	@Override
	public void deletarArtefato() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void editarArtefato() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void criarArtefato() {
		// TODO Auto-generated method stub
		
	}
}
