package model;

import java.util.Date;
import java.util.List;

public class Atividade {
    private Integer codAtividade;
    private String nome;
    private Date dataInicio;
    private Date dataTermino;
    private SalaVirtual salaVirtual;
    private Notificacao notificacao;
    private List<EncontroSincrono> encontroSincrono;

    public List<EncontroSincrono> getEncontroSincrono() {
        return encontroSincrono;
    }

    public Notificacao getNotificacao() {
        return notificacao;
    }

    public SalaVirtual getSalaVirtual() {
        return salaVirtual;
    }

    public Date getDataTermino() {
        return dataTermino;
    }

    public Date getDataInicio() {
        return dataInicio;
    }

    public String getNome() {
        return nome;
    }

    public Integer getCodAtividade() {
        return codAtividade;
    }

    public void consultarAtividade(){
        //
    }

    public void adicionarAtiviade(){
        //
    }

    public void deletarCronograma(){
        //
    }



}
