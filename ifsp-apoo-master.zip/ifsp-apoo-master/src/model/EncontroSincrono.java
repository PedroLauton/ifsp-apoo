package model;

public class EncontroSincrono {
    private String assunto;
    private String descricao;
    private String dataHorario;
    private String tags;
    private String linkConteudo;
    private String ramo;
    private String recompensa;
    private Atividade atividade;

    public EncontroSincrono(String assunto, String descricao, String dataHorario, String tags, String linkConteudo, String ramo, Atividade atividade) {
        this.assunto = assunto;
        this.descricao = descricao;
        this.dataHorario = dataHorario;
        this.tags = tags;
        this.linkConteudo = linkConteudo;
        this.ramo = ramo;
        this.atividade = atividade;
    }

    public void participarEncontro(){
        //
    }

    public void agendarEncontro(){
        //
    }

    public void gravarEncontro(){
        //
    }

    public void criarInteracao(){
        //
    }
}
