package banco;

public class MensagemBanco {
}
