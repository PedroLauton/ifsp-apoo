package banco;

import com.mysql.jdbc.PreparedStatement;
import model.Atividade;
import model.Professor;

import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;

public class AtividadeBanco {
    public void inserirAtividade(Atividade atividade){
        String query = "INSERT INTO tbatividade(cod, nome, dataInicio, dataTermino, salavirtual) VALUES (?, ?, ?, ?, ?)";

        try{
            Connection conn = Conexao.conexaoMySql();
            PreparedStatement pstm = (PreparedStatement) conn.prepareStatement(query);
            pstm.setInt(1, atividade.getCodAtividade());
            pstm.setString(2, atividade.getNome());
            pstm.setDate(3, (Date) atividade.getDataInicio());
            pstm.setDate(4, (Date) atividade.getDataTermino());
            pstm.setInt(5, atividade.getSalaVirtual().getCodSalaVirtual());
            pstm.execute();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
