package banco;

import com.mysql.jdbc.PreparedStatement;
import model.Enquete;
import model.Pergunta;

import java.sql.Connection;
import java.sql.SQLException;

public class PerguntaBanco {
    public void inserirPergunta(Pergunta pergunta){
        String query = "INSERT INTO tbartefatointeratividade(cod, tipo, titulo, descricao, materia, dataPostagem, opcoes, respostas) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try{
            Connection conn = Conexao.conexaoMySql();
            PreparedStatement pstm = (PreparedStatement) conn.prepareStatement(query);
            pstm.setInt(1, pergunta.getCodArtefato());
            pstm.setString(2, pergunta.getTipo());
            pstm.setString(3, pergunta.getTitulo());
            pstm.setString(4, pergunta.getDescricao());
            pstm.setInt(5, pergunta.getMateria().getCodMateria());
            pstm.setDate(6, pergunta.getDataPostagem());
            pstm.setString(7, pergunta.getOpcoes());
            pstm.setString(8, pergunta.getResposta());
            pstm.execute();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
