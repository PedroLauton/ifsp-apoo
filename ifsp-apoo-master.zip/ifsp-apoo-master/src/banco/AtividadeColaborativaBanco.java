package banco;

import com.mysql.jdbc.PreparedStatement;
import model.AtividadeColaborativa;


import java.sql.Connection;
import java.sql.SQLException;

public class AtividadeColaborativaBanco {
    public void inserirAtividadeColaborativa(AtividadeColaborativa atividadeColaborativa){
        String query = "INSERT INTO tbartefatointeratividade(cod, tipo, titulo, descricao, materia, dataPostagem, requisitos, entregaveis) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try{
            Connection conn = Conexao.conexaoMySql();
            PreparedStatement pstm = (PreparedStatement) conn.prepareStatement(query);
            pstm.setInt(1, atividadeColaborativa.getCodArtefato());
            pstm.setString(2, atividadeColaborativa.getTipo());
            pstm.setString(3, atividadeColaborativa.getTitulo());
            pstm.setString(4, atividadeColaborativa.getDescricao());
            pstm.setInt(5, atividadeColaborativa.getMateria().getCodMateria());
            pstm.setDate(6, atividadeColaborativa.getDataPostagem());
            pstm.setString(7, atividadeColaborativa.getRequisitos());
            pstm.setString(8, atividadeColaborativa.getEntregaveis());
            pstm.execute();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
