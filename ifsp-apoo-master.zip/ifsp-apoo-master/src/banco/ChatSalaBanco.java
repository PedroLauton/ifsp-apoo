package banco;

import com.mysql.jdbc.PreparedStatement;
import model.Atividade;
import model.ChatSala;

import java.sql.Connection;
import java.sql.SQLException;

public class ChatSalaBanco {
    public void inserirChat(ChatSala chatSala){
        String query = "INSERT INTO tbchatsala(cod, titulo, salaVirtual) VALUES (?, ?, ?)";

        try{
            Connection conn = Conexao.conexaoMySql();
            PreparedStatement pstm = (PreparedStatement) conn.prepareStatement(query);
            pstm.setInt(1, chatSala.getCodChat());
            pstm.setString(2, chatSala.getTitulo());
            pstm.setInt(2, chatSala.getSalaVirtual().getCodSalaVirtual());
            pstm.execute();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
