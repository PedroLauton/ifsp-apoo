package banco;

import com.mysql.jdbc.PreparedStatement;
import model.Enquete;

import java.sql.Connection;
import java.sql.SQLException;

public class EnqueteBanco {
    public void inserirEnquete(Enquete enquete){
        String query = "INSERT INTO tbartefatointeratividade(cod, tipo, titulo, descricao, materia, dataPostagem, opcoes, respostas) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try{
            Connection conn = Conexao.conexaoMySql();
            PreparedStatement pstm = (PreparedStatement) conn.prepareStatement(query);
            pstm.setInt(1, enquete.getCodArtefato());
            pstm.setString(2, enquete.getTipo());
            pstm.setString(3, enquete.getTitulo());
            pstm.setString(4, enquete.getDescricao());
            pstm.setInt(5, enquete.getMateria().getCodMateria());
            pstm.setDate(6, enquete.getDataPostagem());
            pstm.setString(7, enquete.getOpcoes());
            pstm.setString(8, enquete.getResposta());
            pstm.execute();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
