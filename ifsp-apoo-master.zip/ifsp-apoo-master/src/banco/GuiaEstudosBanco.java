package banco;

import com.mysql.jdbc.PreparedStatement;
import model.GuiaEstudos;

import java.sql.Connection;
import java.sql.SQLException;

public class GuiaEstudosBanco {
    public void inserirGuiaEstudos(GuiaEstudos guiaEstudos){
        String query = "INSERT INTO tbguiaestudos(titulo, dataInicio, dataFim, ramo, resumo, link) VALUES (?, ?, ?, ?, ?, ?)";

        try{
            Connection conn = Conexao.conexaoMySql();
            PreparedStatement pstm = (PreparedStatement) conn.prepareStatement(query);
            pstm.setString(1, guiaEstudos.getTitulo());
            pstm.setDate(2, guiaEstudos.getDataInicio());
            pstm.setDate(3, guiaEstudos.getDataFim());
            pstm.setString(4, guiaEstudos.getRamo());
            pstm.setString(5, guiaEstudos.getResumo());
            pstm.setString(6, guiaEstudos.getLink());
            pstm.execute();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
