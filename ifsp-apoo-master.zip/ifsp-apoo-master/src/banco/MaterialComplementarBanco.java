package banco;

import com.mysql.jdbc.PreparedStatement;
import model.MaterialComplementar;

import java.sql.Connection;
import java.sql.SQLException;

public class MaterialComplementarBanco {

    public void inserirMaterialComplementar(MaterialComplementar materialComplementar){
        String query = "INSERT INTO tbmaterialcomplementar(arquivo, titulo, miniatura, descricao) VALUES (?, ?, ?, ?)";

        try{
            Connection conn = Conexao.conexaoMySql();
            PreparedStatement pstm = (PreparedStatement) conn.prepareStatement(query);
            pstm.setString(1, materialComplementar.getArquivo());
            pstm.setString(2, materialComplementar.getTitulo());
            pstm.setString(3, materialComplementar.getMiniatura());
            pstm.setString(4, materialComplementar.getDescricao());
            pstm.execute();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
