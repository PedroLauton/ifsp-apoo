package banco;

public class NotificacaoBanco {
}
