package banco;

import com.mysql.jdbc.PreparedStatement;
import model.Desafio;
import model.Enquete;

import java.sql.Connection;
import java.sql.SQLException;

public class DesafioBanco {
    public void inserirDesafio(Desafio desafio){
        String query = "INSERT INTO tbartefatointeratividade(cod, tipo, titulo, descricao, materia, dataPostagem, requisitos) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try{
            Connection conn = Conexao.conexaoMySql();
            PreparedStatement pstm = (PreparedStatement) conn.prepareStatement(query);
            pstm.setInt(1, desafio.getCodArtefato());
            pstm.setString(2, desafio.getTipo());
            pstm.setString(3, desafio.getTitulo());
            pstm.setString(4, desafio.getDescricao());
            pstm.setInt(5, desafio.getMateria().getCodMateria());
            pstm.setDate(6, desafio.getDataPostagem());
            pstm.setString(7, desafio.getRequisitos());
            pstm.execute();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
