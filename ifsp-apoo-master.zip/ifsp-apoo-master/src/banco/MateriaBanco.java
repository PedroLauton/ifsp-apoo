package banco;

import com.mysql.jdbc.PreparedStatement;
import model.Materia;

import java.sql.Connection;
import java.sql.SQLException;

public class MateriaBanco {
    public void inserirMateria(Materia materia){
        String query = "INSERT INTO tbmateria(nome, sigla, desativado, professor) VALUES (?, ?, ?, ?)";

        try{
            Connection conn = Conexao.conexaoMySql();
            PreparedStatement pstm = (PreparedStatement) conn.prepareStatement(query);
            pstm.setString(1, materia.getNome());
            pstm.setString(2, materia.getSigla());
            pstm.setBoolean(3, !materia.getIsAtivo());
            pstm.setInt(4, materia.getProfessor().getMatricula());
            pstm.execute();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
