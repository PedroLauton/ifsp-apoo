package banco;

public class EncontroSincronoBanco {
}
