package banco;

import com.mysql.jdbc.PreparedStatement;
import model.Atividade;
import model.Estudante;
import model.SalaVirtual;

import java.sql.Connection;
import java.sql.SQLException;

public class EstudanteBanco {
    public void inserirEstudante(Estudante estudante){
        String query = "INSERT INTO tbestudante(matricula, nome, cpf, rg, email, telefone, endereco, escola) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try{
            Connection conn = Conexao.conexaoMySql();
            PreparedStatement pstm = (PreparedStatement) conn.prepareStatement(query);
            pstm.setInt(1, estudante.getMatricula());
            pstm.setString(2, estudante.getNome());
            pstm.setString(3, estudante.getCpf());
            pstm.setString(4, estudante.getRg());
            pstm.setString(5, estudante.getEmail());
            pstm.setString(6, estudante.getTelefone());
            pstm.setString(7, estudante.getEndereco());
            pstm.setString(8, estudante.getEscola());
            pstm.execute();

            if(estudante.getSalaVirtual() != null){
                this.inserirEstudanteSalaVirtual(estudante);
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void inserirEstudanteSalaVirtual(Estudante estudante){
        String query = "INSERT INTO tbestudantes_salavirtual(estudante, salavirtual) VALUES (?, ?)";

        try{
            Connection conn = Conexao.conexaoMySql();
            PreparedStatement pstm = (PreparedStatement) conn.prepareStatement(query);

            for (SalaVirtual salaVirtual : estudante.getSalaVirtual()) {
                pstm.setInt(1, estudante.getMatricula());
                pstm.setInt(2, salaVirtual.getCodSalaVirtual());
                pstm.addBatch();
            }

            pstm.executeBatch();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
