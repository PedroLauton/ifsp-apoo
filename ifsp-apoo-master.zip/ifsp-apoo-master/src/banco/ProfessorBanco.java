package banco;

import com.mysql.jdbc.PreparedStatement;
import model.MaterialComplementar;
import model.Professor;

import java.sql.Connection;
import java.sql.SQLException;

public class ProfessorBanco {
    public void inserirProfessor(Professor professor){
        String query = "INSERT INTO tbprofessor(matricula, especialidade, nome, cpf, rg, email, telefone, endereco) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try{
            Connection conn = Conexao.conexaoMySql();
            PreparedStatement pstm = (PreparedStatement) conn.prepareStatement(query);
            pstm.setInt(1, professor.getMatricula());
            pstm.setString(2, professor.getEspecialidade());
            pstm.setString(3, professor.getNome());
            pstm.setString(4, professor.getCpf());
            pstm.setString(5, professor.getRg());
            pstm.setString(6, professor.getEmail());
            pstm.setString(7, professor.getTelefone());
            pstm.setString(8, professor.getEndereco());
            pstm.execute();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
