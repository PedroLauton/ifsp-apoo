package banco;

import com.mysql.jdbc.PreparedStatement;
import model.Atividade;
import model.Estudante;
import model.SalaVirtual;

import java.sql.Connection;
import java.sql.SQLException;

public class SalaVirtualBanco {
    public void inserirSalaVirtual(SalaVirtual salaVirtual){
        String query = "INSERT INTO tbsalavirtual(cod, nome, descricao, miniatura, volumetriaEstudantes) VALUES (?, ?, ?, ?, ?)";

        try{
            Connection conn = Conexao.conexaoMySql();
            PreparedStatement pstm = (PreparedStatement) conn.prepareStatement(query);
            pstm.setInt(1, salaVirtual.getCodSalaVirtual());
            pstm.setString(2, salaVirtual.getNome());
            pstm.setString(3, salaVirtual.getDescricao());
            pstm.setString(4, salaVirtual.getMiniatura());
            pstm.setInt(5, salaVirtual.getVolumetria());
            pstm.execute();

            if(salaVirtual.getEstudantes() != null){
                this.inserirSalaVirtualEstudantes(salaVirtual);
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void inserirSalaVirtualEstudantes(SalaVirtual salaVirtual){
        String query = "INSERT INTO tbestudantes_salavitual(estudante, salavirtual) VALUES (?, ?)";

        try{
            Connection conn = Conexao.conexaoMySql();
            PreparedStatement pstm = (PreparedStatement) conn.prepareStatement(query);

            for (Estudante estudante : salaVirtual.getEstudantes()) {
                pstm.setInt(1, estudante.getMatricula());
                pstm.setInt(2, salaVirtual.getCodSalaVirtual());
                pstm.addBatch();
            }

            pstm.executeBatch();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
